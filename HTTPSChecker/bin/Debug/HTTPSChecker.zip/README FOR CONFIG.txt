here is some azenv link: 

https://proxyjudge.us/azenv.php
https://azenv.net/
http://www.wfuchs.de/azenv.php
http://www2t.biglobe.ne.jp/~take52/test/env.cgi
https://www.proxy-listen.de/azenv.php
http://pascal.hoez.free.fr/azenv.php